#!/usr/bin/env python3
"""
run_fss.py — minimal FSS driver.

For each lattice in LATTICES (each entry is (L_x, L_y, T_x, T_y)):
  1. (optional) locate beta_c via a Gram-Charlier susceptibility scan
  2. run the C++ Ising simulator at beta_c (or BETA_FIXED)
  3. load the connected two-point function

Then plot:
  - the susceptibility scan + GC fit per lattice (beta_c finder visualizer)
  - G_conn(t) along each of the 3 boundary cycles, t in [0, 1] (one panel
    per cycle, all lattice sizes overlaid)
  - FSS extrapolation of the boundary midpoint G_conn(t = 1/2) vs 1/L for
    each cycle, with a linear (a + b/L) and quadratic (a + b/L + c/L^2) fit
    — this is the geometry/coupling-optimization continuum target.

Edit the CONFIG block below and click Run.
"""
# ===========================================================================
# CONFIG
# ===========================================================================
# Each entry: (L_x, L_y, T_x, T_y).  Untwisted = T_x = T_y = 0.
# For a twisted parallelogram set T_x, T_y to integer twist offsets;
# e.g. (16, 16, 4, 4) is a 1/4 twist on a 16x16 lattice.
LATTICES    = [
    (8,  8,  0, 0),
    (12, 12, 0, 0),
    (16, 16, 0, 0),
    (24, 24, 0, 0),
    (32, 32, 0, 0),
    (48, 48, 0, 0),
    (64, 64, 0, 0),
]
K1, K2, K3  = 1.0, 1.0, 1.0         # nearest-neighbour couplings (equilateral)
DELTA_SIGMA = 0.125                 # spin scaling dimension (2D Ising = 1/8)

# beta_c selection ---------------------------------------------------------
FIND_BETA_C = True                  # True → run scan; False → use BETA_FIXED
BETA_FIXED  = 0.27465               # used only when FIND_BETA_C is False
SCAN_LO     = 0.05                  # scan bracket for beta_c finder
SCAN_HI     = 0.40

# beta_c finder MC stats (cheap, used only during the susceptibility scan)
SCAN_N_TRAJ_COARSE = 4000           # traj/point in the initial coarse pass
SCAN_N_TRAJ_FINE   = 8000           # traj/point in the 3 refinement passes
SCAN_N_COARSE      = 13             # # of beta points in the coarse pass
SCAN_N_REFINE      = 7              # # of beta points in each refine pass

# production MC ------------------------------------------------------------
N_TRAJ      = 80000
N_SKIP      = 20
N_THERM     = 4000

TAG         = "hi"                  # output dir name → results/<tag>/

# boundary-cycle sampling --------------------------------------------------
N_T_SAMPLES = 33                    # # of points per cycle in [0, 1]
# ===========================================================================

import os
import sys
import pickle
import subprocess
import time

import numpy as np
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, "lib"))
import mc_engine  # noqa: E402
from cost import boundary_paths, _tile_interp, _SQRT3_2  # noqa: E402


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def _exe_path():
    base = os.path.join(_HERE, "bin", "ising_tri_twisted_parallelogram")
    cands = (base + ".exe", base) if os.name == "nt" else (base, base + ".exe")
    for c in cands:
        if os.path.exists(c):
            return c
    sys.exit(f"ERROR: simulator binary not found in {os.path.join(_HERE, 'bin')}.\n"
             f"Build it with `make` from this directory.")


def _label(Lx, Ly, Tx, Ty):
    return (f"L{Lx}x{Ly}" if Tx == 0 and Ty == 0
            else f"L{Lx}x{Ly}_T{Tx}x{Ty}")


def run_one_lattice(Lx, Ly, Tx, Ty, exe, out_pkl):
    """Find beta_c (optionally), run production MC, load two-point data.
    Returns dict with Lx, Ly, Tx, Ty, beta_c, scan_betas, scan_chis, rows."""
    lab = _label(Lx, Ly, Tx, Ty)
    if os.path.exists(out_pkl):
        with open(out_pkl, "rb") as f:
            return pickle.load(f)

    scratch = os.path.join(_HERE, "results", TAG, "_scratch", lab)
    os.makedirs(scratch, exist_ok=True)

    # ---- (1) beta_c
    if FIND_BETA_C:
        print(f"[scan] {lab:>14}  finding beta_c in [{SCAN_LO}, {SCAN_HI}] ...",
              flush=True)
        t0 = time.time()
        beta_c, _, chi_peak, sb, sc, _ = mc_engine.find_beta_c(
            exe, Lx, Ly, Tx, Ty, K1, K2, K3, SCAN_LO, SCAN_HI,
            n_coarse=SCAN_N_COARSE,
            n_refine=SCAN_N_REFINE,
            n_refine2=SCAN_N_REFINE,
            n_refine3=SCAN_N_REFINE,
            n_traj_coarse=SCAN_N_TRAJ_COARSE,
            n_traj_fine=SCAN_N_TRAJ_FINE,
            data_dir=os.path.join(scratch, "scan"))
        print(f"[scan] {lab:>14}  beta_c = {beta_c:.5f}  "
              f"chi_peak = {chi_peak:.2f}  ({time.time()-t0:.1f}s)", flush=True)
    else:
        beta_c = BETA_FIXED
        sb, sc = [], []
        print(f"[scan] {lab:>14}  using BETA_FIXED = {beta_c:.5f}", flush=True)

    # ---- (2) production MC at beta_c
    print(f"[mc]   {lab:>14}  running production at beta = {beta_c:.5f} ...",
          flush=True)
    t0 = time.time()
    _, subdir = mc_engine.run_simulator(
        exe, Lx, Ly, Tx, Ty, K1, K2, K3, beta_c,
        n_traj=N_TRAJ, n_skip=N_SKIP, n_therm=N_THERM,
        data_dir=os.path.join(scratch, "prod"))
    if subdir is None:
        sys.exit(f"could not locate simulator output for {lab}")

    # ---- (3) load two-point file
    rows = []
    with open(os.path.join(subdir, "two_point_all_to_all.dat")) as f:
        for ln in f:
            if ln.startswith("#"):
                continue
            p = ln.split()
            if len(p) >= 7:
                rows.append((int(p[1]), int(p[2]),
                             float(p[5]), float(p[6])))  # (m, n, conn, conn_err)
    print(f"[mc]   {lab:>14}  done in {time.time()-t0:.1f}s  "
          f"({len(rows)} two-point entries)", flush=True)

    # Convert rows → dict expected by _tile_interp.
    data = {(m, n): {"conn": g, "conn_err": e} for (m, n, g, e) in rows}
    payload = {"Lx": Lx, "Ly": Ly, "Tx": Tx, "Ty": Ty,
               "beta_c": float(beta_c),
               "scan_betas": list(sb), "scan_chis": list(sc),
               "data": data}
    with open(out_pkl, "wb") as f:
        pickle.dump(payload, f)
    return payload


def sample_boundary_cycles(payload, t_fracs):
    """Sample G_conn along the 3 boundary cycles at fractions t in [0, 1].
    Returns G[c, k], sG[c, k] arrays of shape (3, len(t_fracs))."""
    Lx, Ly = payload["Lx"], payload["Ly"]
    Tx, Ty = payload["Tx"], payload["Ty"]
    data = payload["data"]
    iG = _tile_interp(data, Lx, Ly, Tx, Ty, "conn",     copies=2)
    iE = _tile_interp(data, Lx, Ly, Tx, Ty, "conn_err", copies=2)
    paths = boundary_paths(Lx, Ly, Tx, Ty)
    G  = np.zeros((3, len(t_fracs)))
    sG = np.zeros_like(G)
    for c, (dm, dn) in enumerate(paths):
        ex, ey = dm + 0.5 * dn, _SQRT3_2 * dn
        pts = np.column_stack([t_fracs * ex, t_fracs * ey])
        G[c]  = np.asarray(iG(pts), dtype=float).ravel()
        sG[c] = np.abs(np.asarray(iE(pts), dtype=float).ravel())
    return G, sG


def _wls_poly(invL, y, sigma, deg):
    """Weighted least-squares polynomial fit; return (intercept, sigma, coeffs)."""
    mask = np.isfinite(y) & np.isfinite(sigma) & (sigma > 0)
    x, yv, sv = invL[mask], y[mask], sigma[mask]
    if len(x) < deg + 1:
        return np.nan, np.nan, None
    X = np.vander(x, deg + 1, increasing=True)
    w = 1.0 / sv ** 2
    try:
        cov = np.linalg.inv((X.T * w) @ X)
    except np.linalg.LinAlgError:
        return np.nan, np.nan, None
    beta = cov @ ((X.T * w) @ yv)
    return float(beta[0]), float(np.sqrt(max(cov[0, 0], 0.0))), beta


def _power_law_fit(Larr, y, sigma):
    """Fit G = A * L^{-B} via WLS in log-log space.

    Error propagation: sigma_{log G} = sigma_G / G  (first order).
    Returns (A, sigma_A, B, sigma_B) or (nan, nan, nan, nan) on failure.
    """
    mask = np.isfinite(y) & np.isfinite(sigma) & (sigma > 0) & (y > 0)
    L, yv, sv = Larr[mask], y[mask], sigma[mask]
    if len(L) < 2:
        return np.nan, np.nan, np.nan, np.nan
    logL = np.log(L)
    logY = np.log(yv)
    slogY = sv / yv                    # sigma_{log G} ≈ sigma_G / G
    w = 1.0 / slogY ** 2
    # Design matrix: [1, logL] → [logA, -B]
    X = np.column_stack([np.ones_like(logL), logL])
    try:
        cov = np.linalg.inv((X.T * w) @ X)
    except np.linalg.LinAlgError:
        return np.nan, np.nan, np.nan, np.nan
    coeffs = cov @ ((X.T * w) @ logY)
    logA, neg_B = float(coeffs[0]), float(coeffs[1])
    A  = np.exp(logA)
    B  = -neg_B
    slogA = float(np.sqrt(max(cov[0, 0], 0.0)))
    sB    = float(np.sqrt(max(cov[1, 1], 0.0)))
    sA    = A * slogA                  # delta A = A * delta(log A)
    return A, sA, B, sB


# --------------------------------------------------------------------------
# Plots
# --------------------------------------------------------------------------

def plot_beta_c_scan(payloads, out_png):
    """Visualise the beta_c finder: chi(beta) scan points + GC fit + peak."""
    fig, ax = plt.subplots(figsize=(8, 6))
    cmap = plt.get_cmap("viridis")
    for i, p in enumerate(payloads):
        if not p["scan_betas"]:
            continue
        col = cmap(i / max(len(payloads) - 1, 1))
        sb = np.array(p["scan_betas"])
        sc = np.array(p["scan_chis"])
        order = np.argsort(sb)
        sb, sc = sb[order], sc[order]
        ax.plot(sb, sc, "o", ms=4, color=col, alpha=0.6,
                label=f"{_label(p['Lx'], p['Ly'], p['Tx'], p['Ty'])}  "
                      f"(β_c = {p['beta_c']:.4f})")
        # Smooth GC curve through the scan points (best-effort).
        try:
            from mc_engine import _gc_fit, _gram_charlier
            params, _ = _gc_fit(list(sb), list(sc), p["beta_c"])
            if params is not None:
                bb = np.linspace(sb.min(), sb.max(), 400)
                ax.plot(bb, _gram_charlier(bb, *params),
                        "-", lw=1.0, color=col, alpha=0.8)
        except Exception:
            pass
        ax.axvline(p["beta_c"], color=col, ls=":", lw=0.8, alpha=0.8)
    ax.set_xlabel(r"$\beta$")
    ax.set_ylabel(r"susceptibility  $\chi(\beta)$")
    ax.set_title("β_c finder — susceptibility scan + Gram-Charlier fit")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    print(f"[plot] saved {out_png}")
    plt.show()


def plot_boundary_cycles(payloads, out_png):
    """G_conn vs t along each of the 3 boundary cycles, all lattices overlaid."""
    t = np.linspace(0.0, 1.0, N_T_SAMPLES)
    fig, axes = plt.subplots(1, 3, figsize=(15, 5), sharey=True)
    cmap = plt.get_cmap("viridis")
    for i, p in enumerate(payloads):
        col = cmap(i / max(len(payloads) - 1, 1))
        G, sG = sample_boundary_cycles(p, t)
        for c in range(3):
            axes[c].errorbar(t, G[c], yerr=sG[c], fmt="o-", ms=3, lw=1,
                             capsize=2, color=col,
                             label=_label(p["Lx"], p["Ly"], p["Tx"], p["Ty"]))
    for c, ax in enumerate(axes):
        ax.set_xlabel(r"$t$ along cycle")
        ax.set_title(f"boundary cycle {c}")
        ax.grid(alpha=0.3)
    axes[0].set_ylabel(r"$G_{\rm conn}(t)$")
    axes[-1].legend(fontsize=8, loc="best")
    fig.suptitle(f"Boundary correlators   (k1, k2, k3) = ({K1:g}, {K2:g}, {K3:g})",
                 fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out_png, dpi=150)
    print(f"[plot] saved {out_png}")
    plt.show()


def plot_midpoint_fss(payloads, out_png):
    """FSS extrapolation of the boundary midpoint to the continuum.

    For a critical correlator on a torus the FSS form is
        G_c(L/2, L) = L^{-2 Delta} * [ A + b/L + c/L^2 + ... ]
    so a polynomial in 1/L on the *raw* G goes to zero (uninformative).
    The right object to extrapolate is the rescaled amplitude
        Y(L) = L^{2 Delta} * G_c(L/2, L)
    which approaches a *universal amplitude* A as 1/L → 0.  We fit Y vs
    1/L with both linear (A + b/L) and quadratic (A + b/L + c/L^2) WLS.
    The intercepts are the continuum amplitudes per cycle; their spread
    across the three cycles is the rotation-symmetry diagnostic that the
    geometry/coupling optimizer should drive to zero.
    """
    t_mid = np.array([0.5])
    Larr = np.array([p["Lx"] for p in payloads], dtype=float)
    invL = 1.0 / Larr
    G_mid  = np.full((3, len(payloads)), np.nan)
    sG_mid = np.full_like(G_mid, np.nan)
    for i, p in enumerate(payloads):
        G, sG = sample_boundary_cycles(p, t_mid)
        G_mid[:, i]  = G[:, 0]
        sG_mid[:, i] = sG[:, 0]

    pow_ = Larr ** (2.0 * DELTA_SIGMA)
    Y    = G_mid  * pow_                # rescaled amplitude
    sY   = sG_mid * pow_

    fig, axes = plt.subplots(2, 3, figsize=(15, 8.5), sharex=True)
    invL_dense = np.linspace(0.0, invL.max() * 1.05, 200)
    cyc_color  = ["#1f77b4", "#d62728", "#2ca02c"]
    summary    = []
    for c in range(3):
        col   = cyc_color[c]
        ax_r  = axes[0, c]   # raw G
        ax_y  = axes[1, c]   # rescaled Y = L^{2 Delta} G

        # ---- raw G(L/2): power-law fit A*L^{-B} ----
        A_pl, sA_pl, B_pl, sB_pl = _power_law_fit(Larr, G_mid[c], sG_mid[c])
        ax_r.errorbar(invL, G_mid[c], yerr=sG_mid[c], fmt="o", ms=6,
                      capsize=3, color=col, mec="k", mew=0.4,
                      label="data", zorder=4)
        if np.isfinite(A_pl):
            L_dense = np.linspace(Larr.min() * 0.9, Larr.max() * 1.1, 300)
            ax_r.plot(1.0 / L_dense, A_pl * L_dense ** (-B_pl),
                      "-", color="k", lw=1.4,
                      label=fr"$A L^{{-B}}$: $A={A_pl:.4f}\pm{sA_pl:.4f}$,"
                            fr" $B={B_pl:.4f}\pm{sB_pl:.4f}$")
            ax_r.legend(fontsize=7, loc="upper left")
        ax_r.axvline(0.0, color="k", lw=0.6, ls=":", alpha=0.5)
        ax_r.set_title(f"cycle {c}: $G_c(L/2)$ power-law fit")
        ax_r.grid(alpha=0.3)

        # ---- rescaled Y(L) vs 1/L → universal amplitude ----
        ax_y.errorbar(invL, Y[c], yerr=sY[c], fmt="o", ms=6,
                      capsize=3, color=col, mec="k", mew=0.4,
                      label="data", zorder=4)

        a_l, sa_l, b_l = _wls_poly(invL, Y[c], sY[c], 1)
        a_q, sa_q, b_q = _wls_poly(invL, Y[c], sY[c], 2)
        if b_l is not None:
            ax_y.plot(invL_dense, b_l[0] + b_l[1] * invL_dense,
                      "-", color="#e05c2b", lw=1.3,
                      label=fr"linear:   $A = {a_l:.4f} \pm {sa_l:.4f}$")
            ax_y.errorbar([0.0], [a_l], yerr=[sa_l], fmt="s", ms=8,
                          color="#e05c2b", mec="k", mew=0.6, zorder=5)
        if b_q is not None:
            ax_y.plot(invL_dense,
                      b_q[0] + b_q[1] * invL_dense + b_q[2] * invL_dense**2,
                      "--", color="#2b7fe0", lw=1.3,
                      label=fr"quad:     $A = {a_q:.4f} \pm {sa_q:.4f}$")
            ax_y.errorbar([0.0], [a_q], yerr=[sa_q], fmt="^", ms=8,
                          color="#2b7fe0", mec="k", mew=0.6, zorder=5)
        ax_y.axvline(0.0, color="k", lw=0.6, ls=":", alpha=0.5)
        ax_y.set_xlim(-0.005, invL.max() * 1.07)
        ax_y.set_xlabel(r"$1 / L$")
        ax_y.set_title(fr"cycle {c}: $L^{{2\Delta}} G_c(L/2)$  "
                       fr"($\Delta={DELTA_SIGMA:g}$)")
        ax_y.grid(alpha=0.3)
        ax_y.legend(fontsize=8, loc="best")
        summary.append((a_l, sa_l, a_q, sa_q,
                         _power_law_fit(Larr, G_mid[c], sG_mid[c])))

    axes[0, 0].set_ylabel(r"$G_c(L/2)$")
    axes[1, 0].set_ylabel(r"$Y(L) = L^{2\Delta}\, G_c(L/2)$")
    fig.suptitle("Boundary-midpoint FSS → continuum amplitude", fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out_png, dpi=150)
    print(f"[plot] saved {out_png}")
    print("\n=== Continuum amplitudes  A = lim L^{2 Delta} G_c(L/2) ===")
    print(f"     {'cycle':>6}   {'lin A (rescaled)':>22}   {'quad A (rescaled)':>22}   "
          f"{'power-law A':>16}   {'B (=2Δ, expect 0.25)':>22}")
    for c, (al, sal, aq, saq, (Apl, sApl, Bpl, sBpl)) in enumerate(summary):
        print(f"     {c:>6d}   {al:>10.5f} ± {sal:<8.5f}   "
              f"{aq:>10.5f} ± {saq:<8.5f}   "
              f"{Apl:>8.5f} ± {sApl:<6.5f}   "
              f"{Bpl:>8.5f} ± {sBpl:<6.5f}")
    A_lin = np.array([s[0] for s in summary])
    B_pl  = np.array([s[4][2] for s in summary])
    print(f"\n     anisotropy  max|A_c - <A>|/<A>  (linear-rescaled) = "
          f"{np.max(np.abs(A_lin - A_lin.mean()))/abs(A_lin.mean()):.3e}")
    print(f"     mean B from power-law fit = {B_pl.mean():.4f}  "
          f"(2D Ising exact = 0.25000)")
    plt.show()


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    exe = _exe_path()
    out_root = os.path.join(_HERE, "results", TAG)
    os.makedirs(out_root, exist_ok=True)

    payloads = [run_one_lattice(Lx, Ly, Tx, Ty, exe,
                                os.path.join(out_root,
                                             f"{_label(Lx, Ly, Tx, Ty)}.pkl"))
                for (Lx, Ly, Tx, Ty) in LATTICES]

    if FIND_BETA_C and any(p["scan_betas"] for p in payloads):
        plot_beta_c_scan(payloads, os.path.join(out_root, "beta_c_scan.png"))
    plot_boundary_cycles(payloads, os.path.join(out_root, "boundary_cycles.png"))
    plot_midpoint_fss(payloads, os.path.join(out_root, "midpoint_fss.png"))


if __name__ == "__main__":
    main()
