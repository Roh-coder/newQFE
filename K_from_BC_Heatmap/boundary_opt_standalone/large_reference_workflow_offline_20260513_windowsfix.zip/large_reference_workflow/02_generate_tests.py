#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Any

from workflow_common import (
    build_test_geometry_map,
    check_required_sections,
    copy_file_atomic,
    ensure_dir,
    ensure_simulator,
    load_json,
    log,
    metadata_path_for_data,
    parse_ratio_list,
    payload_file_name,
    resolve_path,
    run_one_payload,
    save_json,
    timestamp,
)

_HERE = os.path.dirname(os.path.abspath(__file__))


def _check_required_keys(section: dict[str, Any], section_name: str, keys: list[str]) -> None:
    missing = [key for key in keys if key not in section]
    if missing:
        raise ValueError(f"{section_name} is missing keys: {missing}")


def _job_worker(job: dict[str, Any]) -> dict[str, Any]:
    data_path = job["data_path"]
    metadata_path = metadata_path_for_data(data_path)
    legacy_pickle_path = os.path.splitext(data_path)[0] + ".pkl"
    if job["resume"] and os.path.exists(data_path) and os.path.exists(metadata_path):
        if os.path.exists(legacy_pickle_path):
            os.remove(legacy_pickle_path)
        return {
            "status": "skip",
            "L": int(job["L"]),
            "r1": float(job["r1"]),
            "r2": float(job["r2"]),
            "data_path": data_path,
            "metadata_path": metadata_path,
            "message": "reused existing payload",
        }

    couplings = {
        "k3": float(job["k3"]),
        "r1": float(job["r1"]),
        "r2": float(job["r2"]),
        "k1": float(job["r1"]) * float(job["k3"]),
        "k2": float(job["r2"]) * float(job["k3"]),
    }
    try:
        summary = run_one_payload(
            exe=job["exe"],
            lattice=tuple(job["lattice"]),
            couplings=couplings,
            beta_cfg=job["beta_finder"],
            mc_cfg=job["mc"],
            scratch_root=job["scratch_root"],
            label=job["label"],
        )
        copy_file_atomic(summary["all_to_all_file"], data_path)
        save_json(metadata_path, summary)
        if os.path.exists(legacy_pickle_path):
            os.remove(legacy_pickle_path)
        return {
            "status": "ok",
            "L": int(job["L"]),
            "r1": float(job["r1"]),
            "r2": float(job["r2"]),
            "data_path": data_path,
            "metadata_path": metadata_path,
            "beta_c": float(summary["beta_c"]),
            "wall_seconds": float(summary["wall_seconds"]),
            "message": "completed",
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "status": "err",
            "L": int(job["L"]),
            "r1": float(job["r1"]),
            "r2": float(job["r2"]),
            "data_path": data_path,
            "metadata_path": metadata_path,
            "message": str(exc),
        }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Step 2: generate test payloads for all requested L values and "
            "(k1/k3, k2/k3) grid points."
        )
    )
    parser.add_argument(
        "--config",
        type=str,
        default="configs/tests_example.json",
        help="Path to the test-generation config JSON",
    )
    parser.add_argument(
        "--tag",
        type=str,
        default=None,
        help="Optional override for run.tag",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = resolve_path(args.config, _HERE)
    cfg = load_json(config_path)

    check_required_sections(
        cfg,
        ["run", "paths", "execution", "test_family", "couplings", "beta_finder", "mc"],
    )
    if args.tag is not None:
        cfg["run"]["tag"] = args.tag

    _check_required_keys(cfg["run"], "run", ["tag"])
    _check_required_keys(cfg["paths"], "paths", ["results_root", "resume"])
    _check_required_keys(cfg["execution"], "execution", ["n_workers"])
    _check_required_keys(cfg["couplings"], "couplings", ["k3", "k1_over_k3_values", "k2_over_k3_values"])
    _check_required_keys(
        cfg["beta_finder"],
        "beta_finder",
        [
            "beta_lo",
            "beta_hi",
            "n_coarse",
            "n_refine",
            "n_refine2",
            "n_refine3",
            "n_traj_coarse",
            "n_traj_fine",
            "max_shifts",
            "jackknife",
        ],
    )
    _check_required_keys(cfg["mc"], "mc", ["n_traj", "n_skip", "n_therm"])

    tag = str(cfg["run"]["tag"])
    results_root = resolve_path(str(cfg["paths"]["results_root"]), _HERE)
    run_root = os.path.join(results_root, tag)
    test_data_dir = os.path.join(run_root, "test_data")
    grid_root = os.path.join(test_data_dir, "grid")
    scratch_root = os.path.join(run_root, "_mc_scratch", "test_data")
    ensure_dir(test_data_dir)
    ensure_dir(grid_root)
    ensure_dir(scratch_root)

    manifest_path = os.path.join(test_data_dir, "manifest_tests.json")
    resume = bool(cfg["paths"]["resume"])

    geometry_map = build_test_geometry_map(cfg["test_family"])
    sizes = [int(v) for v in cfg["test_family"]["sizes"]]
    r1_values = parse_ratio_list(cfg["couplings"]["k1_over_k3_values"], "couplings.k1_over_k3_values")
    r2_values = parse_ratio_list(cfg["couplings"]["k2_over_k3_values"], "couplings.k2_over_k3_values")
    k3 = float(cfg["couplings"]["k3"])
    if k3 == 0.0:
        raise ValueError("couplings.k3 must be non-zero")

    exe = ensure_simulator(cfg["execution"])

    jobs: list[dict[str, Any]] = []
    for L in sizes:
        Lx, Ly, Tx, Ty = geometry_map[int(L)]
        out_dir = os.path.join(grid_root, f"L{int(L)}")
        ensure_dir(out_dir)
        for r2 in r2_values:
            for r1 in r1_values:
                filename = payload_file_name(L, r1, r2)
                data_path = os.path.join(out_dir, filename)
                jobs.append(
                    {
                        "exe": exe,
                        "L": int(L),
                        "lattice": [int(Lx), int(Ly), int(Tx), int(Ty)],
                        "r1": float(r1),
                        "r2": float(r2),
                        "k3": float(k3),
                        "beta_finder": cfg["beta_finder"],
                        "mc": cfg["mc"],
                        "resume": resume,
                        "scratch_root": scratch_root,
                        "data_path": data_path,
                        "label": f"test_L{int(L)}_r1{float(r1):.6f}_r2{float(r2):.6f}",
                    }
                )

    workers = int(cfg["execution"]["n_workers"])
    if workers < 1:
        raise ValueError("execution.n_workers must be >= 1")

    log(f"Running {len(jobs)} test jobs with workers={workers}")
    results: list[dict[str, Any]] = []

    if workers == 1:
        for idx, job in enumerate(jobs, start=1):
            result = _job_worker(job)
            results.append(result)
            log(
                f"[{idx}/{len(jobs)}] L={result['L']} r1={result['r1']:.6f} "
                f"r2={result['r2']:.6f} status={result['status']}"
            )
    else:
        done = 0
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_job_worker, job) for job in jobs]
            for future in as_completed(futures):
                result = future.result()
                done += 1
                results.append(result)
                log(
                    f"[{done}/{len(jobs)}] L={result['L']} r1={result['r1']:.6f} "
                    f"r2={result['r2']:.6f} status={result['status']}"
                )

    ok_count = sum(1 for r in results if r["status"] == "ok")
    skip_count = sum(1 for r in results if r["status"] == "skip")
    err_count = sum(1 for r in results if r["status"] == "err")

    manifest = {
        "created_at": timestamp(),
        "config_path": config_path,
        "run_tag": tag,
        "run_root": run_root,
        "test_data_dir": test_data_dir,
        "grid_root": grid_root,
        "exe": exe,
        "sizes": sizes,
        "geometry_map": {str(k): list(v) for k, v in geometry_map.items()},
        "k3": k3,
        "k1_over_k3_values": r1_values,
        "k2_over_k3_values": r2_values,
        "summary": {
            "total_jobs": len(jobs),
            "ok": ok_count,
            "skip": skip_count,
            "err": err_count,
        },
        "jobs": sorted(results, key=lambda r: (r["L"], r["r2"], r["r1"])),
        "config": cfg,
    }
    save_json(manifest_path, manifest)
    log(f"Test manifest written: {manifest_path}")

    if err_count > 0:
        raise RuntimeError(f"{err_count} test jobs failed. Check manifest: {manifest_path}")


if __name__ == "__main__":
    main()
