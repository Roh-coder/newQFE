# large_reference_workflow

A collaborator-friendly, large-reference-only workflow for boundary-correlator scoring.

This directory is intentionally simple and explicit:
- Step 1 builds exactly one large reference all-to-all two-point payload.
- Step 2 builds test payloads over user-chosen lattice sizes and coupling-ratio grid.
- Step 3 fits each test channel to the continuum with
  A + B * (1 / L)^C,
  then compares those continuum channels to the same fractional channels of the large reference.

No reference-side continuum extrapolation is used here.

## Why this exists

The original runner in this repository is powerful but monolithic:
- one script handles build, run scheduling, multiple reference modes, monitor UI, and scoring;
- many nested config branches are valid, which increases accidental complexity for handoff.

This replacement workflow favors transparency over flexibility:
- each script has one job;
- each step writes a manifest with paths and summary stats;
- outputs are plain `.dat` data artifacts for auditability (no pickle payloads).

All results are organized into three explicit buckets under each run tag:
- `reference_data`
- `test_data`
- `comparison_analysis_data`

## Directory layout

```text
large_reference_workflow/
  01_generate_reference.py
  02_generate_tests.py
  03_score_continuum_vs_reference.py
  workflow_common.py
  configs/
    reference_example.json
    tests_example.json
    score_example.json
  results/
    <run_tag>/
      reference_data/
      test_data/
      comparison_analysis_data/
```

## Prerequisites

From `boundary_opt_standalone/`:
- Python packages: `numpy`, `scipy`, `matplotlib`
- Build toolchain for simulator (`make`, C++14 compiler)

## Quick start

Run from this directory:

```bash
cd /workspaces/newQFE/K_from_BC_Heatmap/boundary_opt_standalone/large_reference_workflow

python 01_generate_reference.py --config configs/reference_example.json
python 02_generate_tests.py --config configs/tests_example.json
python 03_score_continuum_vs_reference.py --config configs/score_example.json
```

If you use the repository virtual environment:

```bash
/workspaces/newQFE/.venv/bin/python 01_generate_reference.py --config configs/reference_example.json
/workspaces/newQFE/.venv/bin/python 02_generate_tests.py --config configs/tests_example.json
/workspaces/newQFE/.venv/bin/python 03_score_continuum_vs_reference.py --config configs/score_example.json
```

## Step-by-step config guide

### Step 1 config: `reference_example.json`

Edit only these sections:
- `reference_lattice`: `Lx`, `Ly`, `Tx`, `Ty`
- `reference_couplings`: `k3`, `k1_over_k3`, `k2_over_k3` (usually isotropic 1,1)
- `beta_finder`
- `mc`
- `run.tag`

Main output:
- `results/<tag>/reference_data/reference_all_to_all.dat`
- `results/<tag>/reference_data/reference_all_to_all.meta.json`
- `results/<tag>/reference_data/reference_channels.dat`
- `results/<tag>/reference_data/manifest_reference.json`

### Step 2 config: `tests_example.json`

Edit only these sections:
- `test_family.sizes`
- `test_family.geometry_defaults` or `test_family.geometry_map`
- `couplings.k1_over_k3_values`
- `couplings.k2_over_k3_values`
- `beta_finder`
- `mc`
- `execution.n_workers`
- `run.tag`

Main output:
- many `.dat` test correlator files under `results/<tag>/test_data/grid/L*/`
- sidecar metadata files `*.meta.json` alongside each `.dat` file
- `results/<tag>/test_data/manifest_tests.json`

### Step 3 config: `score_example.json`

Edit only these sections:
- `input.reference_data_file`
- `input.reference_metadata_file` (optional; defaults to sidecar `*.meta.json`)
- `input.tests_manifest`
- `analysis.k_values`
- `analysis.k_denominator`
- `analysis.power_fit` (`c_min`, `c_max`, `c_initial`)
- `analysis.fss_plots` (optional: `enabled`, `dpi`, `max_points`)
- `analysis.weighted`
- `run.tag`

Main output:
- `results/<tag>/reference_data/reference_channels_scored.dat`
- `results/<tag>/test_data/raw_test_channels_scored.dat`
- `results/<tag>/comparison_analysis_data/continuum_test_channels.dat`
- `results/<tag>/comparison_analysis_data/channel_comparison.dat`
- `results/<tag>/comparison_analysis_data/score_map.dat`
- `results/<tag>/comparison_analysis_data/score_minimum.dat` (if finite scores exist)
- `results/<tag>/comparison_analysis_data/fss_plot_data.dat`
- `results/<tag>/comparison_analysis_data/fss_plot_index.dat`
- `results/<tag>/comparison_analysis_data/fss_plots/*.png`
- `results/<tag>/comparison_analysis_data/score_heatmap.png`
- `results/<tag>/comparison_analysis_data/zscore_heatmap.png`
- `results/<tag>/comparison_analysis_data/score_zscore_heatmaps.png`
- `results/<tag>/comparison_analysis_data/manifest_score.json`

FSS plot behavior in Step 03:
- one FSS figure is saved per `(k1/k3, k2/k3)` point;
- each panel shows one channel `(cycle, k)`;
- test-size points, fitted curve `A + B(1/L)^C`, continuum intercept `A`, and the large-reference point are all shown together.

## Logic and formulas

For each boundary cycle and each fractional sampling point `t = k / denominator`:

1. Collect test-channel values across sizes `L`.
2. Fit the continuum model:

   `G_test(L) = A + B * (1 / L)^C`

3. Interpret `A` as the continuum test estimate at that `(cycle, t)`.
4. Compare to large-reference channel `G_ref(cycle, t)`.

Per-point score is a channel sum of squared differences:
- unweighted: `sum((A - G_ref)^2)`
- weighted (optional): `sum((A - G_ref)^2 / (sigma_A^2 + sigma_ref^2))`

`z_rms` is also reported from channel z-values where variances are finite.

## Guardrails for collaborators

- Strict required-field checks with readable errors.
- Resume support (`paths.resume`) for long runs.
- Atomic payload writes (`.tmp` then replace) to reduce corruption risk.
- Manifests at every step with paths and summary counts.
- Missing-size warnings at scoring time, with explicit `n_missing_sizes` in `score_map.dat`.

## Notes

- Relative paths in configs are resolved relative to this directory.
- Step 3 can score partial test sets, but continuum fits are better with at least 3 sizes.
- If only two sizes are available for a channel, the fitter falls back to fixed `C=1`.

## Journal

### 2026-05-12: high-stat production run (5 test sizes)

Production configs used:
- `configs/production_reference_20260512.json`
- `configs/production_tests_20260512.json`
- `configs/production_score_20260512.json`

Execution summary:
- Step 1 reference: completed (`run_tag=production_ref_highstats_20260512`)
  - lattice: `80x80`, `(Tx,Ty)=(0,0)`
  - couplings: `(k1/k3, k2/k3)=(1.0, 1.0)`, `k3=1.0`
  - result: `beta_c = 0.270654881862 ± 0.001153760683`
  - payload wall time: `182.536 s`
- Step 2 tests: completed (`run_tag=production_tests_highstats_20260512`)
  - sizes: `[8, 12, 16, 24, 32]`
  - coupling grid: `k1/k3, k2/k3 in {0.9, 1.0, 1.1}` (`3x3` points)
  - jobs: `45/45` completed, `0` errors, `0` skipped
  - summed job wall time: `1084.096 s` (`0.301 h`)
- Step 3 scoring: completed (`run_tag=production_compare_highstats_20260512`)
  - channels scored per point: `21`
  - grid points scored: `9/9`
  - missing-size count: `0` for all points
  - fit mode usage: all `189` channel fits used full power-law mode `A + B*(1/L)^C`

Primary scoring result (unweighted score map):
- best point: `(k1/k3, k2/k3) = (1.0, 1.0)`
- minimum score: `0.04608512592`
- corresponding `z_rms`: `1.444351808`
- second-best score: `0.05834294903` at `(1.1, 1.0)`
- score separation: `+0.01225782311` absolute (`1.266x` relative to minimum)

Interpretation:
- The production scan cleanly prefers the isotropic point `(1.0, 1.0)` under the current unweighted objective.
- The score landscape has strong contrast (worst/min ratio about `3.33e3`), indicating robust rejection of much of the scanned anisotropic grid.
- `z_rms` and raw score are not strictly aligned across points because channel uncertainties vary strongly by point; use both diagnostics together.

Artifacts of interest:
- `results/production_compare_highstats_20260512/comparison_analysis_data/score_map.dat`
- `results/production_compare_highstats_20260512/comparison_analysis_data/score_minimum.dat`
- `results/production_compare_highstats_20260512/comparison_analysis_data/score_zscore_heatmaps.png`
- `results/production_compare_highstats_20260512/comparison_analysis_data/fss_plot_index.dat`
- `results/production_compare_highstats_20260512/comparison_analysis_data/fss_plots/`

Data format check:
- Verified no `.pkl` files in `production_ref_highstats_20260512`, `production_tests_highstats_20260512`, or `production_compare_highstats_20260512`.
