#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime
from typing import Any

import numpy as np

_WORKFLOW_ROOT = os.path.dirname(os.path.abspath(__file__))
_RUNTIME_ROOT = _WORKFLOW_ROOT
_LIB_ROOT = os.path.join(_RUNTIME_ROOT, "lib")
if _LIB_ROOT not in sys.path:
    sys.path.insert(0, _LIB_ROOT)

import mc_engine  # noqa: E402
from cost import _SQRT3_2, _tile_interp, boundary_paths  # noqa: E402


def timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log(message: str) -> None:
    print(f"[{timestamp()}] {message}", flush=True)


def json_default(obj: Any):
    if isinstance(obj, (np.integer, np.floating)):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, tuple):
        return list(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def resolve_path(path: str, base_dir: str) -> str:
    if os.path.isabs(path):
        return os.path.normpath(path)
    return os.path.normpath(os.path.join(base_dir, path))


def load_json(path: str) -> dict[str, Any]:
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path: str, payload: dict[str, Any]) -> None:
    ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, default=json_default)
        handle.write("\n")


def copy_file_atomic(src_path: str, dst_path: str) -> None:
    ensure_dir(os.path.dirname(dst_path))
    tmp = dst_path + ".tmp"
    shutil.copy2(src_path, tmp)
    os.replace(tmp, dst_path)


def metadata_path_for_data(data_path: str) -> str:
    if data_path.lower().endswith(".dat"):
        return data_path[:-4] + ".meta.json"
    return data_path + ".meta.json"


def load_payload_from_dat(data_path: str, metadata_path: str | None = None) -> dict[str, Any]:
    meta_path = metadata_path or metadata_path_for_data(data_path)
    metadata = load_json(meta_path)
    payload = dict(metadata)
    payload["all_to_all_file"] = data_path
    payload["data"] = mc_engine.load_all_to_all(data_path)
    return payload


def default_exe_path() -> str:
    exe = os.path.join(_RUNTIME_ROOT, "bin", "ising_tri_twisted_parallelogram")
    if os.name == "nt":
        exe += ".exe"
    return exe


def _newest_source_mtime() -> float:
    newest = os.path.getmtime(os.path.join(_RUNTIME_ROOT, "Makefile"))
    for folder in ("src", "include"):
        root_dir = os.path.join(_RUNTIME_ROOT, folder)
        for root, _, files in os.walk(root_dir):
            for name in files:
                newest = max(newest, os.path.getmtime(os.path.join(root, name)))
    return newest


def ensure_simulator(execution_cfg: dict[str, Any]) -> str:
    exe = execution_cfg.get("exe") or default_exe_path()
    if not os.path.isabs(exe):
        exe = os.path.join(_RUNTIME_ROOT, exe)
    exe = os.path.normpath(exe)

    auto_build = bool(execution_cfg.get("auto_build", True))
    force_rebuild = bool(execution_cfg.get("force_rebuild", False))
    needs_build = force_rebuild or (not os.path.exists(exe))
    if auto_build and os.path.exists(exe):
        needs_build = needs_build or (_newest_source_mtime() > os.path.getmtime(exe))

    if auto_build and needs_build:
        command = execution_cfg.get("build_command") or ["make"]
        timeout_s = int(execution_cfg.get("build_timeout_s", 600))
        log(f"Building simulator with command: {command}")
        result = subprocess.run(
            command,
            cwd=_RUNTIME_ROOT,
            capture_output=True,
            text=True,
            timeout=timeout_s,
            shell=isinstance(command, str),
        )
        if result.returncode != 0:
            raise RuntimeError(
                "Simulator build failed.\n"
                f"stdout:\n{result.stdout}\n\n"
                f"stderr:\n{result.stderr}"
            )

    if not os.path.exists(exe):
        raise FileNotFoundError(
            f"Simulator executable not found at {exe}. "
            "Either set execution.auto_build=true or provide execution.exe."
        )
    return exe


def require_lattice(cfg: dict[str, Any], section_name: str) -> tuple[int, int, int, int]:
    missing = [key for key in ("Lx", "Ly", "Tx", "Ty") if key not in cfg]
    if missing:
        raise ValueError(f"{section_name} is missing keys: {missing}")
    return (int(cfg["Lx"]), int(cfg["Ly"]), int(cfg["Tx"]), int(cfg["Ty"]))


def couplings_from_ratio(couplings_cfg: dict[str, Any], section_name: str) -> dict[str, float]:
    missing = [key for key in ("k3", "k1_over_k3", "k2_over_k3") if key not in couplings_cfg]
    if missing:
        raise ValueError(f"{section_name} is missing keys: {missing}")

    k3 = float(couplings_cfg["k3"])
    if k3 == 0.0:
        raise ValueError(f"{section_name}.k3 must be non-zero")
    r1 = float(couplings_cfg["k1_over_k3"])
    r2 = float(couplings_cfg["k2_over_k3"])
    return {
        "k3": k3,
        "r1": r1,
        "r2": r2,
        "k1": r1 * k3,
        "k2": r2 * k3,
    }


def build_test_geometry_map(test_family_cfg: dict[str, Any]) -> dict[int, tuple[int, int, int, int]]:
    if "sizes" not in test_family_cfg:
        raise ValueError("test_family.sizes is required")
    sizes = [int(v) for v in test_family_cfg["sizes"]]
    if len(sizes) == 0:
        raise ValueError("test_family.sizes must not be empty")

    geometry_map = test_family_cfg.get("geometry_map")
    if geometry_map is not None:
        out: dict[int, tuple[int, int, int, int]] = {}
        for key, value in geometry_map.items():
            if len(value) != 4:
                raise ValueError(f"test_family.geometry_map[{key}] must have 4 ints")
            out[int(key)] = tuple(int(x) for x in value)
        missing = [L for L in sizes if L not in out]
        if missing:
            raise ValueError(f"test_family.geometry_map is missing sizes: {missing}")
        return {L: out[L] for L in sizes}

    defaults = test_family_cfg.get("geometry_defaults") or {}
    lx_mult = float(defaults.get("Lx_mult", 1.0))
    ly_mult = float(defaults.get("Ly_mult", 1.0))
    tx_frac = float(defaults.get("Tx_frac", 0.0))
    ty_frac = float(defaults.get("Ty_frac", 0.0))

    out = {}
    for L in sizes:
        out[L] = (
            int(round(lx_mult * L)),
            int(round(ly_mult * L)),
            int(round(tx_frac * L)),
            int(round(ty_frac * L)),
        )
    return out


def parse_ratio_list(values: Any, field_name: str) -> list[float]:
    if values is None:
        raise ValueError(f"{field_name} is required")
    out = [float(v) for v in values]
    if len(out) == 0:
        raise ValueError(f"{field_name} must not be empty")
    return out


def run_one_payload(
    exe: str,
    lattice: tuple[int, int, int, int],
    couplings: dict[str, float],
    beta_cfg: dict[str, Any],
    mc_cfg: dict[str, Any],
    scratch_root: str,
    label: str,
) -> dict[str, Any]:
    Lx, Ly, Tx, Ty = lattice
    k1 = couplings["k1"]
    k2 = couplings["k2"]
    k3 = couplings["k3"]

    scratch = os.path.join(scratch_root, label)
    ensure_dir(scratch)
    t0 = time.time()

    beta_c, beta_c_sigma, chi_peak, scan_betas, scan_chis, scan_chi_errs = mc_engine.find_beta_c(
        exe,
        Lx,
        Ly,
        Tx,
        Ty,
        k1,
        k2,
        k3,
        float(beta_cfg["beta_lo"]),
        float(beta_cfg["beta_hi"]),
        n_coarse=int(beta_cfg["n_coarse"]),
        n_refine=int(beta_cfg["n_refine"]),
        n_refine2=int(beta_cfg["n_refine2"]),
        n_refine3=int(beta_cfg["n_refine3"]),
        n_traj_coarse=int(beta_cfg["n_traj_coarse"]),
        n_traj_fine=int(beta_cfg["n_traj_fine"]),
        data_dir=os.path.join(scratch, "scan"),
        max_shifts=int(beta_cfg.get("max_shifts", 4)),
        jackknife=bool(beta_cfg.get("jackknife", False)),
    )

    _, subdir = mc_engine.run_simulator(
        exe,
        Lx,
        Ly,
        Tx,
        Ty,
        k1,
        k2,
        k3,
        beta_c,
        n_traj=int(mc_cfg["n_traj"]),
        n_skip=int(mc_cfg["n_skip"]),
        n_therm=int(mc_cfg["n_therm"]),
        data_dir=os.path.join(scratch, "prod"),
    )
    if subdir is None:
        raise RuntimeError("Simulator did not report output directory")

    all_to_all_path = os.path.join(subdir, "two_point_all_to_all.dat")

    return {
        "label": label,
        "created_at": timestamp(),
        "wall_seconds": float(time.time() - t0),
        "L": int(max(abs(Lx), abs(Ly))),
        "Lx": int(Lx),
        "Ly": int(Ly),
        "Tx": int(Tx),
        "Ty": int(Ty),
        "k1": float(k1),
        "k2": float(k2),
        "k3": float(k3),
        "r1": float(couplings["r1"]),
        "r2": float(couplings["r2"]),
        "beta_c": float(beta_c),
        "beta_c_sigma": float(beta_c_sigma),
        "chi_peak": float(chi_peak),
        "scan_betas": [float(x) for x in scan_betas],
        "scan_chis": [float(x) for x in scan_chis],
        "scan_chi_errs": [float(x) for x in scan_chi_errs],
        "mc": {
            "n_traj": int(mc_cfg["n_traj"]),
            "n_skip": int(mc_cfg["n_skip"]),
            "n_therm": int(mc_cfg["n_therm"]),
        },
        "beta_finder": {
            "beta_lo": float(beta_cfg["beta_lo"]),
            "beta_hi": float(beta_cfg["beta_hi"]),
            "n_coarse": int(beta_cfg["n_coarse"]),
            "n_refine": int(beta_cfg["n_refine"]),
            "n_refine2": int(beta_cfg["n_refine2"]),
            "n_refine3": int(beta_cfg["n_refine3"]),
            "n_traj_coarse": int(beta_cfg["n_traj_coarse"]),
            "n_traj_fine": int(beta_cfg["n_traj_fine"]),
            "max_shifts": int(beta_cfg.get("max_shifts", 4)),
            "jackknife": bool(beta_cfg.get("jackknife", False)),
        },
        "all_to_all_file": all_to_all_path,
    }


def sample_directional_channels(
    payload: dict[str, Any],
    fractions: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    fractions = np.asarray(fractions, dtype=float)
    if np.any((fractions < 0.0) | (fractions > 1.0)):
        raise ValueError("fractions must lie in [0, 1]")

    Lx = int(payload["Lx"])
    Ly = int(payload["Ly"])
    Tx = int(payload["Tx"])
    Ty = int(payload["Ty"])
    data = payload["data"]

    interp_g = _tile_interp(data, Lx, Ly, Tx, Ty, "conn", copies=2)
    interp_s = _tile_interp(data, Lx, Ly, Tx, Ty, "conn_err", copies=2)

    G = np.full((3, len(fractions)), np.nan, dtype=float)
    sG = np.full_like(G, np.nan)

    for cycle, (dm, dn) in enumerate(boundary_paths(Lx, Ly, Tx, Ty)):
        ex = dm + 0.5 * dn
        ey = _SQRT3_2 * dn
        pts = np.column_stack([fractions * ex, fractions * ey])
        G[cycle] = np.asarray(interp_g(pts), dtype=float).ravel()
        sG[cycle] = np.abs(np.asarray(interp_s(pts), dtype=float).ravel())

    return G, sG


def write_dat(path: str, header_lines: list[str], columns: list[str], rows: list[list[Any]]) -> None:
    ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as handle:
        for line in header_lines:
            handle.write(f"# {line}\n")
        handle.write("# columns: " + " ".join(columns) + "\n")
        for row in rows:
            chunks = []
            for value in row:
                if isinstance(value, (int, np.integer)):
                    chunks.append(str(int(value)))
                elif isinstance(value, (float, np.floating)):
                    chunks.append(f"{float(value):.10g}")
                else:
                    chunks.append(str(value))
            handle.write(" ".join(chunks) + "\n")


def payload_file_name(L: int, r1: float, r2: float) -> str:
    return f"test_L{int(L)}_r1{float(r1):.6f}_r2{float(r2):.6f}.dat"


def check_required_sections(config: dict[str, Any], section_names: list[str]) -> None:
    missing = [name for name in section_names if name not in config]
    if missing:
        raise ValueError(f"Config is missing top-level sections: {missing}")
