#!/usr/bin/env python3
"""
cost.py — Anisotropy-penalising p-mean cost (p=4) over the three torus
boundary directions.

For each of the three fundamental torus boundary directions d ∈ {v, u, w},
the correlator is sampled along the corresponding lattice period vector,
parameterised by the arc-length fraction t ∈ [0, 1] *of that period*.
The per-direction L² mismatch is

    C_d = ∫₀¹ [G_test^d(t) - G_ref^d(t)]² dt

and these are aggregated with a p-power mean (p = 4):

    C(r1,r2) = ( (1/3) Σ_d C_d^p )^(1/p)

This punishes anisotropy: a single direction with large C_d dominates
the total, so the optimizer cannot trade a small gain in one direction
for a large drift in another.  At perfect isotropy (C_v = C_u = C_w)
the p-mean equals the common per-direction value.

Curve collapse across differing ref / test geometries
-----------------------------------------------------
The reference and test lattices need NOT share (Lx, Ly, Tx, Ty).  Each
direction's path endpoint is its *own* lattice period vector, so e.g.

    ref  = (13, 16,  3, -3)  →  periods  (13,-3), (3,-16), (-16,19)
    test = (15, 15,  0,  0)  →  periods  (15, 0), (0,-15), (-15,15)

are each parameterised over the unit interval and compared point-by-point
in t.  This is the fractional-arclength curve-collapse hypothesis: at the
critical point, the boundary-directed two-point function along cycle i of
torus A should collapse onto the same function of t as cycle i of torus B.

The integral is approximated by the trapezoid rule on n_samples uniformly
spaced points.

Uncertainty in C
----------------
By linear error propagation:

    σ_C² ≈ Σ_d  ∫₀¹ 4 (G_test - G_ref)² (σ_test² + σ_ref²) dt

so that SNR = C / σ_C tells the optimizer when its current best is
statistically distinguishable from the reference.

Public API
----------
  boundary_paths(Lx, Ly, Tx, Ty) -> list of three (dm, dn) direction vectors
  l2_cost(ref_data, test_data, ...) -> (cost, sigma_cost, per_dir, per_dir_sigma)
  snr(cost, sigma_cost) -> float
  snr_status(cost, sigma_cost) -> str  ("ok" | "marginal" | "need_more_stats")
"""

import math
from math import gcd

import numpy as np
from scipy.interpolate import LinearNDInterpolator


# ---------------------------------------------------------------------------
# Torus geometry helpers
# ---------------------------------------------------------------------------

def boundary_paths(Lx, Ly, Tx, Ty):
    """Three fundamental boundary direction vectors of the torus."""
    return [
        (Lx,        Ty),
        (Tx,        -Ly),
        (-Lx - Tx,  Ly - Ty),
    ]


_SQRT3_2 = math.sqrt(3.0) / 2.0


def _triangular_xy(m, n):
    return m + 0.5 * n, _SQRT3_2 * n


def _tile_interp(data, Lx, Ly, Tx, Ty, field, copies=2):
    """LinearNDInterpolator over the data tiled across torus copies."""
    keys = list(data.keys())
    m_arr = np.array([k[0] for k in keys], dtype=float)
    n_arr = np.array([k[1] for k in keys], dtype=float)
    c_arr = np.array([data[k][field] for k in keys], dtype=float)

    x0, y0 = _triangular_xy(m_arr, n_arr)
    vx = Lx + 0.5 * Ty;  vy = _SQRT3_2 * Ty
    ux = Tx - 0.5 * Ly;  uy = -_SQRT3_2 * Ly

    x_all, y_all, c_all = [x0], [y0], [c_arr]
    for a in range(-copies, copies + 1):
        for b in range(-copies, copies + 1):
            if a == 0 and b == 0:
                continue
            x_all.append(x0 + a * vx + b * ux)
            y_all.append(y0 + a * vy + b * uy)
            c_all.append(c_arr)

    x_all = np.concatenate(x_all)
    y_all = np.concatenate(y_all)
    c_all = np.concatenate(c_all)
    pts = np.column_stack([x_all, y_all])
    _, uid = np.unique(np.round(pts, 8), axis=0, return_index=True)
    return LinearNDInterpolator(pts[uid], c_all[uid])


# ---------------------------------------------------------------------------
# Core cost function
# ---------------------------------------------------------------------------

def _direction_lattice_steps(dm, dn):
    """Lattice points along the boundary direction (dm, dn) of a torus.

    The line t·(dm, dn) for t ∈ [0, 1] passes through ``g`` lattice
    sites, where ``g = gcd(|dm|, |dn|)`` (with gcd(x, 0) = |x|).  Sites
    are at (k·dm/g, k·dn/g) for k = 0, …, g − 1.

    Returns
    -------
    ks : np.ndarray  — integer indices k = 0, 1, …, g − 1
    ms : np.ndarray  — integer site coordinate m = k·dm/g
    ns : np.ndarray  — integer site coordinate n = k·dn/g
    """
    g = gcd(abs(int(dm)), abs(int(dn)))
    if g == 0:
        return np.array([0]), np.array([0]), np.array([0])
    ks = np.arange(g, dtype=int)
    ms = ks * (int(dm) // g)
    ns = ks * (int(dn) // g)
    return ks, ms, ns


def _wrap_to_test_torus(m, n, Lx, Ly, Tx, Ty):
    """Reduce (m, n) into a canonical torus key by undoing torus shifts.

    The two-point file stores (m, n) with the convention used by the
    simulator.  For lookup we try the original key, then the eight
    neighbouring torus copies, returning the first one that exists in
    ``data``.  Centralised here so callers don't reinvent it.
    """
    # Generated by callers; this helper is intentionally tiny.
    raise NotImplementedError  # placeholder, see _lookup_test_value


def _lookup_test_value(data, m, n, Lx, Ly, Tx, Ty, copies=2):
    """Return data[(m, n)] with torus periodicity, or None if absent."""
    vx_m, vx_n = Lx, Ty
    ux_m, ux_n = Tx, -Ly
    for a in range(-copies, copies + 1):
        for b in range(-copies, copies + 1):
            key = (int(m - a * vx_m - b * ux_m),
                   int(n - a * vx_n - b * ux_n))
            if key in data:
                return data[key]
    return None


def _l2_cost_test_native(ref_data, test_data,
                         test_Lx, test_Ly, test_Tx, test_Ty,
                         ref_Lx, ref_Ly, ref_Tx, ref_Ty,
                         copies=2, power=2):
    """Test-native cost: ref interpolated, test sampled at lattice sites.

    For each of the three boundary directions of the *test* lattice we
    enumerate the integer lattice sites along that period vector and
    look up the test correlator there directly (no interpolation).
    The reference correlator is interpolated at the matching physical
    (x, y) positions of the *reference* boundary direction.

    Per-direction cost:  C_d = mean_k (G_test_k − G_ref_k)^power
    Aggregate cost:      C   = mean_d C_d
    """
    if power not in (2, 4):
        raise ValueError(f"cost_power must be 2 or 4, got {power}")

    iref     = _tile_interp(ref_data, ref_Lx, ref_Ly, ref_Tx, ref_Ty,
                            "conn", copies)
    iref_err = _tile_interp(ref_data, ref_Lx, ref_Ly, ref_Tx, ref_Ty,
                            "conn_err", copies)

    ref_paths  = boundary_paths(ref_Lx,  ref_Ly,  ref_Tx,  ref_Ty)
    test_paths = boundary_paths(test_Lx, test_Ly, test_Tx, test_Ty)

    per_dir       = []
    per_dir_sigma = []
    dir_labels    = ["v", "u", "w"]

    for (rdm, rdn), (tdm, tdn) in zip(ref_paths, test_paths):
        ks, ms, ns = _direction_lattice_steps(tdm, tdn)
        if len(ks) < 2:
            per_dir.append(0.0)
            per_dir_sigma.append(0.0)
            continue

        # Test values at the integer lattice sites along the test path.
        G_test_list, e_test_list, t_list = [], [], []
        N = len(ks)
        for k, mk, nk in zip(ks, ms, ns):
            entry = _lookup_test_value(test_data, mk, nk,
                                       test_Lx, test_Ly, test_Tx, test_Ty,
                                       copies=copies)
            if entry is None:
                continue
            G_test_list.append(entry["conn"])
            e_test_list.append(entry["conn_err"])
            t_list.append(k / N)
        if len(G_test_list) < 2:
            per_dir.append(0.0)
            per_dir_sigma.append(0.0)
            continue

        G_test = np.asarray(G_test_list, dtype=float)
        e_test = np.abs(np.asarray(e_test_list, dtype=float))
        t_arr  = np.asarray(t_list, dtype=float)

        # Reference, interpolated at the matching fractional positions
        # along the reference period vector.
        rex, rey = rdm + 0.5 * rdn, _SQRT3_2 * rdn
        pts_ref  = np.column_stack([t_arr * rex, t_arr * rey])
        G_ref = np.asarray(iref(pts_ref), dtype=float)
        e_ref = np.abs(np.asarray(iref_err(pts_ref), dtype=float))

        mask = (np.isfinite(G_ref) & np.isfinite(G_test)
                & np.isfinite(e_ref) & np.isfinite(e_test))
        if mask.sum() < 2:
            per_dir.append(0.0)
            per_dir_sigma.append(0.0)
            continue

        diff     = G_test[mask] - G_ref[mask]
        var_prop = e_ref[mask]**2 + e_test[mask]**2

        if power == 2:
            C_d = float(np.mean(diff ** 2))
            # σ²(C_d) = (1/N²) Σ_k (2·diff_k)² · var_k
            V_d = float(np.sum((2.0 * diff) ** 2 * var_prop)
                        / (mask.sum() ** 2))
        else:  # power == 4
            C_d = float(np.mean(diff ** 4))
            V_d = float(np.sum((4.0 * diff ** 3) ** 2 * var_prop)
                        / (mask.sum() ** 2))

        per_dir.append(C_d)
        per_dir_sigma.append(math.sqrt(max(V_d, 0.0)))

    # Plain mean over the three directions.
    N_dir = len(per_dir)
    if N_dir == 0:
        cost, sigma_cost = 0.0, 0.0
    else:
        cost       = float(sum(per_dir) / N_dir)
        sigma_cost = math.sqrt(sum(s * s for s in per_dir_sigma)) / N_dir

    parts = "  ".join(f"{l}={c:.4e}±{s:.4e}"
                      for l, c, s in zip(dir_labels, per_dir, per_dir_sigma))
    print(f"    [test-native p={power}] per-dir: {parts}  "
          f"total={cost:.4e}±{sigma_cost:.4e}")

    return cost, sigma_cost, per_dir, per_dir_sigma


def l2_cost(ref_data, test_data,
            test_Lx, test_Ly, test_Tx, test_Ty,
            ref_Lx, ref_Ly, ref_Tx, ref_Ty,
            n_samples=400, copies=2,
            cost_mode="l4mean_both_interp",
            cost_power=2):
    """
    Cost between reference and test correlators along the three boundary
    directions.

    Parameters
    ----------
    cost_mode : str
        - ``"l4mean_both_interp"`` (default, legacy):
              Both reference and test correlators are interpolated and
              sampled on the same uniform grid of ``n_samples`` points
              per direction; per-direction L² values are aggregated with
              an L⁴ power-mean.
        - ``"test_native"``:
              Only the reference correlator is interpolated.  The test
              correlator is read directly at the test lattice sites that
              lie along each boundary direction (no interpolation).  The
              cost is a plain mean over directions of the mean of
              residuals raised to ``cost_power`` (2 → squared, 4 → quart).
    cost_power : int
        Exponent applied to per-site residuals in ``"test_native"`` mode.
        Must be 2 or 4.  Ignored in ``"l4mean_both_interp"`` mode.

    Returns
    -------
    cost           : float
    sigma_cost     : float
    per_dir        : list[float]
    per_dir_sigma  : list[float]
    """
    if cost_mode == "test_native":
        return _l2_cost_test_native(
            ref_data, test_data,
            test_Lx, test_Ly, test_Tx, test_Ty,
            ref_Lx, ref_Ly, ref_Tx, ref_Ty,
            copies=copies, power=int(cost_power),
        )
    if cost_mode != "l4mean_both_interp":
        raise ValueError(f"unknown cost_mode={cost_mode!r}")

    iref      = _tile_interp(ref_data,  ref_Lx,  ref_Ly,  ref_Tx,  ref_Ty,  "conn",     copies)
    itest     = _tile_interp(test_data, test_Lx, test_Ly, test_Tx, test_Ty, "conn",     copies)
    iref_err  = _tile_interp(ref_data,  ref_Lx,  ref_Ly,  ref_Tx,  ref_Ty,  "conn_err", copies)
    itest_err = _tile_interp(test_data, test_Lx, test_Ly, test_Tx, test_Ty, "conn_err", copies)

    ref_paths  = boundary_paths(ref_Lx,  ref_Ly,  ref_Tx,  ref_Ty)
    test_paths = boundary_paths(test_Lx, test_Ly, test_Tx, test_Ty)

    # Torus periodicity: t=0 and t=1 are the same lattice site, so we sample
    # only t ∈ [0, 1) and use the periodic trapezoid rule (= uniform sum /
    # n_samples).  Including t=1 pushes LinearNDInterpolator onto the
    # convex-hull boundary of the tiled point cloud, which gives a spurious
    # spike in the residuals at t ≈ 1.
    t = np.linspace(0.0, 1.0, n_samples, endpoint=False)

    per_dir       = []
    per_dir_sigma = []
    dir_labels    = ["v", "u", "w"]

    for (rdm, rdn), (tdm, tdn) in zip(ref_paths, test_paths):
        rex, rey = rdm + 0.5 * rdn, _SQRT3_2 * rdn
        tex, tey = tdm + 0.5 * tdn, _SQRT3_2 * tdn
        pts_ref  = np.column_stack([t * rex, t * rey])
        pts_test = np.column_stack([t * tex, t * tey])

        G_ref  = np.asarray(iref(pts_ref),       dtype=float)
        G_test = np.asarray(itest(pts_test),     dtype=float)
        e_ref  = np.abs(np.asarray(iref_err(pts_ref),   dtype=float))
        e_test = np.abs(np.asarray(itest_err(pts_test), dtype=float))

        mask = (np.isfinite(G_ref) & np.isfinite(G_test)
                & np.isfinite(e_ref) & np.isfinite(e_test))

        if mask.sum() < 4:
            per_dir.append(0.0)
            per_dir_sigma.append(0.0)
            continue

        diff     = G_test[mask] - G_ref[mask]
        var_prop = e_ref[mask]**2 + e_test[mask]**2

        # Periodic trapezoid rule over t ∈ [0, 1) with n_samples equal
        # intervals of width 1/n_samples — which reduces to a mean.
        # Both the cost integral and its variance-propagation integral
        # use the same ∫…dt convention as before, so SNR thresholds
        # retain their previous calibration.
        C_d = float(np.mean(diff ** 2))
        V_d = float(np.mean(4.0 * diff ** 2 * var_prop))

        per_dir.append(C_d)
        per_dir_sigma.append(math.sqrt(max(V_d, 0.0)))

    # Aggregate across directions with a p-power mean (p=4) instead of a
    # plain sum.  This penalises anisotropy: a single direction with a
    # large C_d dominates the total, so the optimizer cannot trade a
    # small gain in one direction for a large drift in another.  At
    # perfect isotropy (C_v = C_u = C_w) the p-mean equals each C_d.
    #
    #     cost = ( (1/N) Σ_d C_d^p )^(1/p),  p = 4, N = 3
    #
    # Error propagation:
    #     ∂cost/∂C_d = (1/N) C_d^(p-1) · cost^(1-p)
    #     σ_cost²    = Σ_d (∂cost/∂C_d)² σ_{C_d}²
    P     = 4
    N_dir = len(per_dir)
    if N_dir == 0 or all(c == 0.0 for c in per_dir):
        cost       = 0.0
        sigma_cost = 0.0
    else:
        mean_p = sum(c ** P for c in per_dir) / N_dir
        cost   = mean_p ** (1.0 / P)
        if cost > 0.0:
            grads = [(c ** (P - 1)) / (N_dir * cost ** (P - 1))
                     for c in per_dir]
            sigma_cost = math.sqrt(sum((g * s) ** 2
                                       for g, s in zip(grads, per_dir_sigma)))
        else:
            sigma_cost = 0.0

    parts = "  ".join(f"{l}={c:.4e}±{s:.4e}"
                      for l, c, s in zip(dir_labels, per_dir, per_dir_sigma))
    print(f"    [L⁴-mean] per-dir: {parts}  "
          f"total={cost:.4e}±{sigma_cost:.4e}")

    return cost, sigma_cost, per_dir, per_dir_sigma


# ---------------------------------------------------------------------------
# SNR helpers
# ---------------------------------------------------------------------------

def snr(cost, sigma_cost):
    if sigma_cost <= 0.0:
        return float("inf")
    return cost / sigma_cost


def snr_status(cost, sigma_cost):
    s = snr(cost, sigma_cost)
    if s < 1.0:
        return "need_more_stats"
    if s < 3.0:
        return "marginal"
    return "ok"
