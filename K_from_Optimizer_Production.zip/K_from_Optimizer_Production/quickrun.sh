#!/usr/bin/env bash
# =============================================================================
# quickrun.sh — K_from_Optimizer_Production: offline plug-and-play launcher
#
# USAGE
#   chmod +x quickrun.sh
#   ./quickrun.sh                          # equilateral smoke-test (fast)
#   ./quickrun.sh 4_5_6                    # 4-5-6 triangle production run
#   ./quickrun.sh custom --max-evals 50    # custom: edit CONFIG inside run.py
#
# PRESETS (first positional arg)
#   (none)        Equilateral 12×12, 20 evals — quick smoke test (~2 min)
#   4_5_6         4-5-6 triangle cross-geometry, 150 evals (production)
#   equil_large   Equilateral 24×24, 40 evals
#   custom        Uses CONFIG defaults in run.py; pass extra args after
#
# All extra arguments after the preset name are forwarded verbatim to run.py.
# =============================================================================

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ── 1. Python check ───────────────────────────────────────────────────────────
PYTHON=""
for candidate in python3 python python3.12 python3.11 python3.10; do
    if command -v "$candidate" &>/dev/null; then
        ver=$("$candidate" -c "import sys; print(sys.version_info >= (3,10))" 2>/dev/null)
        if [[ "$ver" == "True" ]]; then
            PYTHON="$candidate"
            break
        fi
    fi
done

if [[ -z "$PYTHON" ]]; then
    echo "ERROR: Python 3.10+ not found on PATH. Please install it and re-run."
    exit 1
fi

echo "Using Python: $($PYTHON --version)"

# ── 2. Virtual environment ────────────────────────────────────────────────────
VENV_DIR="$SCRIPT_DIR/.venv"
if [[ ! -f "$VENV_DIR/bin/activate" ]]; then
    echo "Creating virtual environment in .venv/ ..."
    "$PYTHON" -m venv "$VENV_DIR"
fi
source "$VENV_DIR/bin/activate"
PY="$VENV_DIR/bin/python"

# ── 3. Install dependencies ───────────────────────────────────────────────────
echo "Installing Python dependencies ..."
"$PY" -m pip install --quiet --upgrade pip
"$PY" -m pip install --quiet -r requirements.txt

# ── 4. Build the C++ simulator ────────────────────────────────────────────────
if [[ "$(uname)" == "MINGW"* ]] || [[ "$(uname)" == "MSYS"* ]]; then
    EXE="bin/ising_tri_twisted_parallelogram.exe"
else
    EXE="bin/ising_tri_twisted_parallelogram"
fi

if [[ ! -x "$EXE" ]]; then
    echo "Building C++ simulator (requires g++ / make) ..."
    make all
else
    echo "Simulator binary already built: $EXE"
fi

# ── 5. Select preset ──────────────────────────────────────────────────────────
PRESET="${1:-smoke}"
shift 2>/dev/null || true   # allow no arguments

case "$PRESET" in

  smoke|"")
    echo ""
    echo "=== PRESET: equilateral smoke-test (12×12, 20 evals) ==="
    RUN_NAME="smoke_$(date +%Y%m%d_%H%M%S)"
    "$PY" run.py \
        --ref-Lx 12 --ref-Ly 12 --ref-Tx 0 --ref-Ty 0 \
        --test-Lx 12 --test-Ly 12 --test-Tx 0 --test-Ty 0 \
        --x0 1.0 1.0 --cma-sigma0 0.10 --max-evals 20 \
        --n-traj-prod 10000 --reweight-n-traj 20000 \
        --no-dashboard --run-name "$RUN_NAME" \
        "$@"
    ;;

  4_5_6)
    echo ""
    echo "=== PRESET: 4-5-6 triangle production run (13×16, 150 evals) ==="
    echo "    Analytic target: r1≈5.0652  r2≈7.7429  β_c≈0.0628"
    RUN_NAME="4_5_6_$(date +%Y%m%d_%H%M%S)"
    "$PY" run.py \
        --ref-Lx 13 --ref-Ly 16 --ref-Tx -3 --ref-Ty 3 \
        --test-Lx 13 --test-Ly 16 --test-Tx 0 --test-Ty 0 \
        --x0 3.0 4.0 --cma-sigma0 3.0 --max-evals 150 \
        --n-traj-prod 20000 --reweight-n-traj 40000 \
        --multidonor-2pass --n-workers 2 \
        --save-frames --no-dashboard \
        --run-name "$RUN_NAME" \
        "$@"
    ;;

  equil_large)
    echo ""
    echo "=== PRESET: equilateral 24×24 (40 evals) ==="
    RUN_NAME="equil24_$(date +%Y%m%d_%H%M%S)"
    "$PY" run.py \
        --ref-Lx 24 --ref-Ly 24 --ref-Tx 0 --ref-Ty 0 \
        --test-Lx 24 --test-Ly 24 --test-Tx 0 --test-Ty 0 \
        --x0 1.0 1.0 --cma-sigma0 0.10 --max-evals 40 \
        --n-traj-prod 20000 --reweight-n-traj 40000 \
        --no-dashboard --run-name "$RUN_NAME" \
        "$@"
    ;;

  custom)
    echo ""
    echo "=== PRESET: custom (using CONFIG defaults in run.py + your args) ==="
    RUN_NAME="custom_$(date +%Y%m%d_%H%M%S)"
    "$PY" run.py --no-dashboard --run-name "$RUN_NAME" "$@"
    ;;

  *)
    echo "Unknown preset: '$PRESET'"
    echo "Valid presets: smoke, 4_5_6, equil_large, custom"
    exit 1
    ;;

esac

echo ""
echo "Done. Results saved in results/$RUN_NAME/"
