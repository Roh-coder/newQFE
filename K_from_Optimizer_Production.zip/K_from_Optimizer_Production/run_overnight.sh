#!/usr/bin/env bash
# run_overnight.sh — 4-run validation suite (legacy / reweight serial /
# reweight+fallback / reweight+fallback+parallel).  Wall budget ~30–90 min on
# a 12×12 lattice depending on hardware.
#
# Usage:
#   bash run_overnight.sh [results_root]
#
# Default results_root = ./results/_overnight.  Each run goes to
# <root>/A_legacy/, <root>/B_reweight/, <root>/C_reweight_fallback/,
# <root>/D_parallel/.  Aggregate report at <root>/OVERNIGHT_REPORT.md
# is produced by check_overnight.py at the end.

set -euo pipefail

# Usage: bash run_overnight.sh [results_root] [--fast]
#   --fast  uses a tiny 6×6 lattice with 10 evals (~2 min) to verify all code
#           paths before committing to a full overnight run.

ROOT="results/_overnight"
FAST=0
for arg in "$@"; do
    case "$arg" in
        --fast) FAST=1 ;;
        *)      ROOT="$arg" ;;
    esac
done

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

mkdir -p "$ROOT"
echo "[overnight] writing to $ROOT  (fast=$FAST)"

if [[ $FAST -eq 1 ]]; then
    # Tiny smoke run: 6×6 lattice, 10 evals each, ~2 min total.
    COMMON=(--test-Lx 6 --test-Ly 6 --ref-Lx 6 --ref-Ly 6
            --max-evals 10 --cma-popsize 4 --cma-sigma0 0.10
            --n-traj-prod 3000 --reweight-n-traj 6000
            --save-every 1 --no-dashboard --results-dir "$ROOT")
else
    # Full overnight run: 12×12 lattice, 30 evals each, ~30–90 min.
    COMMON=(--test-Lx 12 --test-Ly 12 --ref-Lx 12 --ref-Ly 12
            --max-evals 30 --cma-popsize 6 --cma-sigma0 0.10
            --n-traj-prod 10000 --reweight-n-traj 20000
            --save-every 1 --no-dashboard --results-dir "$ROOT")
fi

t_start=$SECONDS

echo "──────── Run A: legacy 3-pass scan, 1 worker ────────"
python run.py "${COMMON[@]}" --no-reweight --n-workers 1 \
    --run-name A_legacy 2>&1 | tee "$ROOT/A_legacy.log"

echo "──────── Run B: reweight (no fallback exercised), 1 worker ────────"
python run.py "${COMMON[@]}" --n-workers 1 \
    --run-name B_reweight 2>&1 | tee "$ROOT/B_reweight.log"

echo "──────── Run C: reweight + 3-pass fallback, 1 worker ────────"
# Force the fallback to fire often by squeezing the reweight bracket.
python run.py "${COMMON[@]}" --n-workers 1 --reweight-n-traj 5000 \
    --run-name C_reweight_fallback 2>&1 | tee "$ROOT/C_reweight_fallback.log"

echo "──────── Run D: reweight + fallback, auto workers ────────"
python run.py "${COMMON[@]}" --n-workers 0 \
    --run-name D_parallel 2>&1 | tee "$ROOT/D_parallel.log"

t_total=$(( SECONDS - t_start ))
echo "[overnight] total wall: ${t_total}s"

python check_overnight.py "$ROOT"
echo "[overnight] report → $ROOT/OVERNIGHT_REPORT.md"
