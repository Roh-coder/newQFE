#!/usr/bin/env python3
"""
run.py — single-entry orchestrator for the K_from_BC_Heatmap workflow.

Wraps the three stages (precompute → cost-replay → plot) into one
configurable script with rich progress output.  Every knob is exposed as
both a CONFIG dict (edit at top of file) and a command-line flag (CLI
overrides CONFIG).

Stages
------
  precompute : run MC on test=(L,L,0,0) and ref=(L,L,T,T) for each L,
               for every (r1,r2) on the grid, find β_c and dump pickles.
  compute    : replay cost.l2_cost in chosen mode(s) and fit cost(L)
               vs 1/L → cost_inf.
  plot       : render per-L + continuum + sigma heatmaps.

Use --stages to pick a subset, e.g. ``--stages precompute`` for a long
overnight MC run, then ``--stages compute plot`` later to replay any
cost mode without re-running MC.

Status output
-------------
Every minute (configurable via --status-interval) the precompute stage
prints a heartbeat with #ok / #err / #remaining, mean wall per point,
and an ETA.  Per-job lines are also printed as before; redirect stdout
to a log file for offline runs:

    nohup python3 run.py --tag prod_2026 > run_prod_2026.log 2>&1 &
    tail -f run_prod_2026.log
"""
from __future__ import annotations

import argparse
import json
import os
import pickle
import shutil
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timedelta

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

import mc_engine          # noqa: E402
import cost as cost_module  # noqa: E402
from precompute_grid import _geom_test, _geom_ref, _point_path, _run_one  # noqa: E402
from compute_landscape import _fit_continuum  # noqa: E402


# ===========================================================================
# DEFAULT CONFIG  — edit here OR override on the command line
# ===========================================================================
CONFIG = {
    # --- output / bookkeeping ---------------------------------------------
    "tag":              "prod",                  # results/<tag>/
    "exe":              None,                    # None → bin/<simulator>
    "stages":           ["precompute", "compute", "plot"],

    # --- physics grid ------------------------------------------------------
    "sizes":            [12, 16, 24],            # FSS sizes (≥2 needed)
    "twist_frac":       0.25,                    # ref-geom T = round(α·L)
    "r_min":            0.5,
    "r_max":            3.0,
    "r_step":           0.25,

    # --- Monte Carlo -------------------------------------------------------
    "n_traj":           50000,                   # production trajectories
    "n_traj_coarse":    2000,                    # β_c finder coarse pass
    "n_traj_fine":      4000,                    # β_c finder fine pass
    "n_skip":           20,                      # MC measurement spacing
    "n_therm":          2000,                    # thermalisation sweeps
    "beta_seed":        (0.05, 0.40),            # initial β bracket
    "n_workers":        4,                       # parallel MC processes

    # --- cost replay -------------------------------------------------------
    # Run multiple modes in one go; first mode is the default for plotting.
    "cost_modes":       ["test_native"],
    "cost_power":       2,                       # used by test_native
    "fit":              "linear",                # 'linear' | 'quadratic'

    # --- plotting ----------------------------------------------------------
    "plot_log":         False,
    "plot_vmax":        None,

    # --- monitoring --------------------------------------------------------
    "status_interval":  60.0,                    # heartbeat seconds
}


# ===========================================================================
# Pretty-print helpers
# ===========================================================================
_T0_GLOBAL = time.time()


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _elapsed(t0=None) -> str:
    s = time.time() - (t0 if t0 is not None else _T0_GLOBAL)
    return str(timedelta(seconds=int(s)))


def log(msg: str) -> None:
    print(f"[{_ts()}  +{_elapsed()}]  {msg}", flush=True)


def banner(title: str) -> None:
    bar = "=" * 72
    print(f"\n{bar}\n[{_ts()}  +{_elapsed()}]  {title}\n{bar}", flush=True)


def fmt_eta(t_per_job: float, remaining: int) -> str:
    if t_per_job <= 0 or remaining <= 0:
        return "—"
    sec = int(t_per_job * remaining)
    return str(timedelta(seconds=sec))


# ===========================================================================
# Stage 1: precompute (MC)
# ===========================================================================
def stage_precompute(cfg: dict) -> dict:
    banner(f"STAGE 1/3 — PRECOMPUTE  tag={cfg['tag']}")
    exe = cfg["exe"] or os.path.join(_HERE, "bin", "ising_tri_twisted_parallelogram")
    if not os.path.exists(exe):
        log(f"ERROR: simulator not found: {exe}")
        sys.exit(1)
    log(f"simulator: {exe}")

    out_root = os.path.join(_HERE, "results", cfg["tag"])
    scratch_root = os.path.join(out_root, "_mc_scratch")
    os.makedirs(out_root, exist_ok=True)
    os.makedirs(scratch_root, exist_ok=True)

    rs = np.arange(cfg["r_min"], cfg["r_max"] + 1e-9, cfg["r_step"])
    points = [(float(r1), float(r2)) for r1 in rs for r2 in rs]

    jobs = []
    for L in cfg["sizes"]:
        for kind, geom_fn in (
            ("test", lambda L=L: _geom_test(L)),
            ("ref",  lambda L=L: _geom_ref(L, cfg["twist_frac"])),
        ):
            Lx, Ly, Tx, Ty = geom_fn()
            grid_dir = os.path.join(out_root, "grid", f"L{L}", kind)
            os.makedirs(grid_dir, exist_ok=True)
            for r1, r2 in points:
                out_pkl = _point_path(grid_dir, r1, r2)
                label = f"L{L}_{kind}_r1{r1:.3f}_r2{r2:.3f}"
                jobs.append((exe, label, Lx, Ly, Tx, Ty, r1, r2,
                             cfg["n_traj"], cfg["n_traj_coarse"],
                             cfg["n_traj_fine"],
                             cfg["beta_seed"][0], cfg["beta_seed"][1],
                             scratch_root, out_pkl))

    n_total = len(jobs)
    n_existing = sum(1 for j in jobs if os.path.exists(j[-1]))
    n_to_do = n_total - n_existing
    log(f"plan: sizes={cfg['sizes']}  twist_frac={cfg['twist_frac']}")
    log(f"plan: {len(points)} (r1,r2) × {len(cfg['sizes'])} L × 2 geoms "
        f"= {n_total} jobs ({n_existing} cached, {n_to_do} to run)")
    log(f"plan: n_traj_prod={cfg['n_traj']}  scan=({cfg['n_traj_coarse']},"
        f"{cfg['n_traj_fine']})  workers={cfg['n_workers']}")
    log(f"plan: out → {out_root}")

    if n_to_do == 0:
        log("nothing to do — all points already cached.")
        return {"out_root": out_root, "n_ok": 0, "n_skip": n_existing, "n_err": 0}

    t_start = time.time()
    t_last_status = t_start
    n_ok = n_skip = n_err = 0
    completed = 0
    walls = []  # finished-job wall times

    with ProcessPoolExecutor(max_workers=cfg["n_workers"]) as ex:
        futs = {ex.submit(_run_one, j): j for j in jobs}
        for fut in as_completed(futs):
            label, status, info = fut.result()
            completed += 1
            if status == "ok":
                n_ok += 1
                walls.append(info["wall"])
                log(f"[{completed:4d}/{n_total}] ok  {label}  "
                    f"β_c={info['beta_c']:.5f}  wall={info['wall']:.1f}s")
            elif status == "skip":
                n_skip += 1
            else:
                n_err += 1
                log(f"[{completed:4d}/{n_total}] ERR {label}  "
                    f"{info.get('msg', '?')}")

            now = time.time()
            if now - t_last_status >= cfg["status_interval"]:
                done_now = n_ok + n_err
                remaining = n_to_do - done_now
                mean_wall = (sum(walls) / len(walls)) if walls else 0.0
                throughput = (mean_wall / max(cfg["n_workers"], 1))
                eta = fmt_eta(throughput, remaining)
                pct = 100.0 * done_now / max(n_to_do, 1)
                log(f"--- status  done={done_now}/{n_to_do} ({pct:.1f}%)  "
                    f"ok={n_ok} err={n_err}  mean_wall={mean_wall:.1f}s  "
                    f"throughput≈{throughput:.1f}s/job  ETA≈{eta} ---")
                t_last_status = now

    wall = time.time() - t_start
    manifest = {
        "tag": cfg["tag"],
        "sizes": cfg["sizes"], "twist_frac": cfg["twist_frac"],
        "r_min": cfg["r_min"], "r_max": cfg["r_max"], "r_step": cfg["r_step"],
        "n_traj_prod": cfg["n_traj"],
        "n_traj_scan_coarse": cfg["n_traj_coarse"],
        "n_traj_scan_fine": cfg["n_traj_fine"],
        "beta_seed": list(cfg["beta_seed"]),
        "wall_s": round(wall, 1),
        "n_total": n_total, "n_ok_this_run": n_ok,
        "n_skip_this_run": n_skip, "n_err_this_run": n_err,
        "test_geoms": {str(L): list(_geom_test(L)) for L in cfg["sizes"]},
        "ref_geoms": {str(L): list(_geom_ref(L, cfg["twist_frac"]))
                      for L in cfg["sizes"]},
    }
    with open(os.path.join(out_root, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    shutil.rmtree(scratch_root, ignore_errors=True)

    log(f"DONE precompute: wall={wall:.1f}s  ok={n_ok} skip={n_skip} err={n_err}")
    log(f"manifest → {os.path.join(out_root, 'manifest.json')}")
    return {"out_root": out_root, "n_ok": n_ok, "n_skip": n_skip, "n_err": n_err}


# ===========================================================================
# Stage 2: compute cost & continuum extrapolation
# ===========================================================================
def stage_compute(cfg: dict, mode: str) -> dict:
    banner(f"STAGE 2/3 — COMPUTE  tag={cfg['tag']}  mode={mode}  fit={cfg['fit']}")
    root = os.path.join(_HERE, "results", cfg["tag"])
    mpath = os.path.join(root, "manifest.json")
    if not os.path.exists(mpath):
        log(f"ERROR: manifest missing: {mpath}")
        sys.exit(1)
    with open(mpath) as f:
        manifest = json.load(f)
    sizes = list(manifest["sizes"])
    twist_frac = manifest["twist_frac"]

    rs = np.arange(manifest["r_min"], manifest["r_max"] + 1e-9,
                   manifest["r_step"])
    n = len(rs)
    R1, R2 = np.meshgrid(rs, rs, indexing="ij")

    COST_L  = {L: np.full((n, n), np.nan) for L in sizes}
    SIGMA_L = {L: np.full((n, n), np.nan) for L in sizes}
    BETAC_T = {L: np.full((n, n), np.nan) for L in sizes}
    BETAC_R = {L: np.full((n, n), np.nan) for L in sizes}
    COST_INF  = np.full((n, n), np.nan)
    SIGMA_INF = np.full((n, n), np.nan)
    SLOPE_INF = np.full((n, n), np.nan)
    OK_INF    = np.zeros((n, n), dtype=bool)

    fit_records = []
    n_full = n_partial = n_missing = 0
    t0 = time.time()
    last_status = t0
    total_pts = n * n
    done_pts = 0

    for i, r1 in enumerate(rs):
        for j, r2 in enumerate(rs):
            done_pts += 1
            costs_per_L = []; sigmas_per_L = []; Ls_used = []
            for L in sizes:
                test_pkl = _point_path(
                    os.path.join(root, "grid", f"L{L}", "test"), r1, r2)
                ref_pkl = _point_path(
                    os.path.join(root, "grid", f"L{L}", "ref"), r1, r2)
                if not (os.path.exists(test_pkl) and os.path.exists(ref_pkl)):
                    continue
                with open(test_pkl, "rb") as f:
                    pt = pickle.load(f)
                with open(ref_pkl, "rb") as f:
                    pr = pickle.load(f)
                BETAC_T[L][i, j] = pt["beta_c"]
                BETAC_R[L][i, j] = pr["beta_c"]
                try:
                    c, s, _pd, _pds = cost_module.l2_cost(
                        pr["data"], pt["data"],
                        pt["Lx"], pt["Ly"], pt["Tx"], pt["Ty"],
                        pr["Lx"], pr["Ly"], pr["Tx"], pr["Ty"],
                        cost_mode=mode, cost_power=cfg["cost_power"],
                    )
                except Exception as e:  # noqa: BLE001
                    log(f"  [skip cost] L={L} r=({r1:.2f},{r2:.2f}): {e}")
                    continue
                COST_L[L][i, j]  = c
                SIGMA_L[L][i, j] = s
                costs_per_L.append(c); sigmas_per_L.append(s); Ls_used.append(L)
            if not costs_per_L:
                n_missing += 1
            elif len(costs_per_L) < len(sizes):
                n_partial += 1
            else:
                n_full += 1
                cinf, sinf, slope, ok = _fit_continuum(
                    Ls_used, costs_per_L, sigmas_per_L, mode=cfg["fit"])
                COST_INF[i, j] = cinf
                SIGMA_INF[i, j] = sinf
                SLOPE_INF[i, j] = slope
                OK_INF[i, j] = ok
                fit_records.append({
                    "r1": float(r1), "r2": float(r2),
                    "Ls": [int(L) for L in Ls_used],
                    "costs": [float(c) for c in costs_per_L],
                    "sigmas": [float(s) for s in sigmas_per_L],
                    "cost_inf": float(cinf), "sigma_inf": float(sinf),
                    "slope": float(slope), "ok": bool(ok),
                })

            now = time.time()
            if now - last_status >= cfg["status_interval"]:
                pct = 100.0 * done_pts / total_pts
                log(f"--- compute status  {done_pts}/{total_pts} pts ({pct:.1f}%)  "
                    f"full={n_full} partial={n_partial} missing={n_missing} ---")
                last_status = now

    wall = time.time() - t0
    log(f"DONE compute: full={n_full}  partial={n_partial}  missing={n_missing}  "
        f"wall={wall:.1f}s")

    out_name = f"cost_{mode}"
    npz = os.path.join(root, f"{out_name}.npz")
    np.savez(
        npz,
        rs=rs, R1=R1, R2=R2,
        sizes=np.array(sizes, dtype=int),
        twist_frac=twist_frac,
        cost_inf=COST_INF, sigma_inf=SIGMA_INF,
        slope_inf=SLOPE_INF, ok_inf=OK_INF,
        **{f"cost_L{L}": COST_L[L] for L in sizes},
        **{f"sigma_L{L}": SIGMA_L[L] for L in sizes},
        **{f"betac_test_L{L}": BETAC_T[L] for L in sizes},
        **{f"betac_ref_L{L}": BETAC_R[L] for L in sizes},
    )
    json_path = os.path.join(root, f"{out_name}_fits.json")
    with open(json_path, "w") as f:
        json.dump({
            "tag": cfg["tag"], "cost_mode": mode,
            "cost_power": cfg["cost_power"], "fit": cfg["fit"],
            "sizes": sizes, "twist_frac": twist_frac,
            "points": fit_records,
        }, f, indent=2)
    log(f"wrote {npz}")
    log(f"wrote {json_path}")

    # Quick continuum-summary printout for the operator.
    finite = COST_INF[np.isfinite(COST_INF)]
    if finite.size:
        idx = np.unravel_index(np.nanargmin(COST_INF), COST_INF.shape)
        log(f"continuum cost: min={float(np.nanmin(COST_INF)):.4e}  "
            f"max={float(np.nanmax(COST_INF)):.4e}  "
            f"argmin=(r1={rs[idx[0]]:.3f}, r2={rs[idx[1]]:.3f})")
    return {"npz": npz, "fits": json_path}


# ===========================================================================
# Stage 3: plot
# ===========================================================================
def stage_plot(cfg: dict, mode: str) -> str:
    banner(f"STAGE 3/3 — PLOT  tag={cfg['tag']}  mode={mode}")
    # Defer import until needed (matplotlib is heavy).
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    root = os.path.join(_HERE, "results", cfg["tag"])
    npz_path = os.path.join(root, f"cost_{mode}.npz")
    if not os.path.exists(npz_path):
        log(f"ERROR: {npz_path} missing — run compute stage first.")
        sys.exit(1)
    z = np.load(npz_path)
    rs = z["rs"]
    sizes = list(z["sizes"])
    twist_frac = float(z["twist_frac"])
    cost_inf = z["cost_inf"]
    sigma_inf = z["sigma_inf"]

    plot_dir = os.path.join(root, "plots")
    os.makedirs(plot_dir, exist_ok=True)

    def _heatmap(ax, Z, title, log_scale=False, vmax=None, cmap="viridis"):
        Zp = Z.copy()
        if log_scale:
            Zp = np.log10(np.where(Zp > 0, Zp, np.nan))
        finite = Zp[np.isfinite(Zp)]
        if vmax is None and finite.size > 0:
            vmax = float(np.nanpercentile(finite, 99))
        vmin = float(np.nanmin(finite)) if finite.size > 0 else 0.0
        extent = [rs[0], rs[-1], rs[0], rs[-1]]
        im = ax.imshow(Zp.T, origin="lower", extent=extent, aspect="auto",
                       cmap=cmap, vmin=vmin, vmax=vmax)
        if finite.size > 0:
            idx = np.unravel_index(np.nanargmin(Z), Z.shape)
            ax.plot(rs[idx[0]], rs[idx[1]], "w*", ms=10,
                    markeredgecolor="k",
                    label=f"min=({rs[idx[0]]:.2f},{rs[idx[1]]:.2f})")
            ax.legend(loc="upper right", fontsize=7)
        ax.set_xlabel("r1"); ax.set_ylabel("r2")
        ax.set_title(title, fontsize=10)
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    n_panels = len(sizes) + 2
    n_cols = min(3, n_panels)
    n_rows = (n_panels + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols,
                             figsize=(4.6 * n_cols, 4.0 * n_rows),
                             squeeze=False)
    axes_flat = axes.flatten()
    for k, L in enumerate(sizes):
        _heatmap(axes_flat[k], z[f"cost_L{L}"],
                 f"L={L}  cost={mode}",
                 log_scale=cfg["plot_log"], vmax=cfg["plot_vmax"])
    _heatmap(axes_flat[len(sizes)], cost_inf,
             f"continuum (L→∞)  fit={mode}",
             log_scale=cfg["plot_log"], vmax=cfg["plot_vmax"])
    _heatmap(axes_flat[len(sizes) + 1], sigma_inf,
             "σ(continuum extrapolation)", cmap="magma")
    for ax in axes_flat[n_panels:]:
        ax.axis("off")
    fig.suptitle(
        f"Untwisted vs twisted cost landscape  "
        f"(tag={cfg['tag']}, twist_frac={twist_frac}, sizes={sizes})",
        fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    panel_out = os.path.join(plot_dir,
                             f"landscape_{mode}{'_log' if cfg['plot_log'] else ''}.png")
    fig.savefig(panel_out, dpi=140); plt.close(fig)
    log(f"wrote {panel_out}")

    fig, ax = plt.subplots(figsize=(5.5, 4.6))
    _heatmap(ax, cost_inf,
             f"Continuum cost (twist_frac={twist_frac})",
             log_scale=cfg["plot_log"], vmax=cfg["plot_vmax"])
    fig.tight_layout()
    cont_out = os.path.join(plot_dir,
                            f"continuum_{mode}{'_log' if cfg['plot_log'] else ''}.png")
    fig.savefig(cont_out, dpi=160); plt.close(fig)
    log(f"wrote {cont_out}")
    return panel_out


# ===========================================================================
# CLI plumbing
# ===========================================================================
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    # bookkeeping
    p.add_argument("--tag", default=CONFIG["tag"])
    p.add_argument("--exe", default=CONFIG["exe"])
    p.add_argument("--stages", nargs="+",
                   default=CONFIG["stages"],
                   choices=["precompute", "compute", "plot"],
                   help="subset of stages to run")
    # physics grid
    p.add_argument("--sizes", type=int, nargs="+", default=CONFIG["sizes"])
    p.add_argument("--twist-frac", type=float, default=CONFIG["twist_frac"])
    p.add_argument("--r-min", type=float, default=CONFIG["r_min"])
    p.add_argument("--r-max", type=float, default=CONFIG["r_max"])
    p.add_argument("--r-step", type=float, default=CONFIG["r_step"])
    # MC
    p.add_argument("--n-traj", type=int, default=CONFIG["n_traj"])
    p.add_argument("--n-traj-coarse", type=int, default=CONFIG["n_traj_coarse"])
    p.add_argument("--n-traj-fine",   type=int, default=CONFIG["n_traj_fine"])
    p.add_argument("--n-skip",  type=int, default=CONFIG["n_skip"])
    p.add_argument("--n-therm", type=int, default=CONFIG["n_therm"])
    p.add_argument("--beta-seed", type=float, nargs=2,
                   default=list(CONFIG["beta_seed"]))
    p.add_argument("--n-workers", type=int, default=CONFIG["n_workers"])
    # cost
    p.add_argument("--cost-modes", nargs="+",
                   default=CONFIG["cost_modes"],
                   choices=["l4mean_both_interp", "test_native",
                            "spectral", "affine_fit", "huber_log"])
    p.add_argument("--cost-power", type=int, default=CONFIG["cost_power"])
    p.add_argument("--fit", default=CONFIG["fit"],
                   choices=["linear", "quadratic"])
    # plotting
    p.add_argument("--plot-log", action="store_true",
                   default=CONFIG["plot_log"])
    p.add_argument("--plot-vmax", type=float, default=CONFIG["plot_vmax"])
    # monitoring
    p.add_argument("--status-interval", type=float,
                   default=CONFIG["status_interval"],
                   help="seconds between heartbeat status lines")
    return p


def cfg_from_args(args: argparse.Namespace) -> dict:
    cfg = dict(CONFIG)
    cfg.update({
        "tag": args.tag, "exe": args.exe, "stages": args.stages,
        "sizes": args.sizes, "twist_frac": args.twist_frac,
        "r_min": args.r_min, "r_max": args.r_max, "r_step": args.r_step,
        "n_traj": args.n_traj,
        "n_traj_coarse": args.n_traj_coarse,
        "n_traj_fine":   args.n_traj_fine,
        "n_skip": args.n_skip, "n_therm": args.n_therm,
        "beta_seed": tuple(args.beta_seed),
        "n_workers": args.n_workers,
        "cost_modes": args.cost_modes,
        "cost_power": args.cost_power,
        "fit": args.fit,
        "plot_log": args.plot_log, "plot_vmax": args.plot_vmax,
        "status_interval": args.status_interval,
    })
    return cfg


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    cfg = cfg_from_args(args)

    banner(f"K_from_BC_Heatmap run.py  tag={cfg['tag']}  "
           f"stages={cfg['stages']}")
    log(f"config:\n{json.dumps({k: (list(v) if isinstance(v, tuple) else v) for k, v in cfg.items()}, indent=2)}")

    # Persist this run's config alongside the data for reproducibility.
    run_dir = os.path.join(_HERE, "results", cfg["tag"])
    os.makedirs(run_dir, exist_ok=True)
    with open(os.path.join(run_dir, "run_config.json"), "w") as f:
        json.dump({k: (list(v) if isinstance(v, tuple) else v)
                   for k, v in cfg.items()}, f, indent=2)

    if "precompute" in cfg["stages"]:
        stage_precompute(cfg)
    if "compute" in cfg["stages"]:
        for mode in cfg["cost_modes"]:
            stage_compute(cfg, mode)
    if "plot" in cfg["stages"]:
        for mode in cfg["cost_modes"]:
            stage_plot(cfg, mode)

    banner(f"ALL DONE  total wall={_elapsed()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
