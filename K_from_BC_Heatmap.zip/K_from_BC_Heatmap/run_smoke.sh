#!/usr/bin/env bash
#
# run_smoke.sh — minimal end-to-end smoke test for K_from_BC_Heatmap.
#
# Tiny sizes / few trajectories so it finishes in a couple of minutes on
# a single workstation.  This is NOT a production run; it only verifies
# that the precompute → cost-replay → plot pipeline works.
#
# Production: bump --sizes, --r-step, and --n-traj (see README.md).
set -euo pipefail
cd "$(dirname "$0")"

TAG=${TAG:-smoke}

echo "[smoke] precompute_grid.py"
python3 precompute_grid.py \
  --tag "$TAG" \
  --sizes 6 8 \
  --twist-frac 0.25 \
  --r-min 0.5 --r-max 1.5 --r-step 0.5 \
  --n-traj 800 \
  --n-traj-coarse 400 \
  --n-traj-fine  600 \
  --n-workers 2

for MODE in huber_log test_native; do
  echo "[smoke] compute_landscape.py mode=$MODE"
  python3 compute_landscape.py --tag "$TAG" --cost-mode "$MODE" --fit linear

  echo "[smoke] plot_landscape.py mode=$MODE"
  python3 plot_landscape.py --tag "$TAG" --cost-mode "$MODE"
done

echo "[smoke] DONE"
ls -la "results/$TAG/plots/"
