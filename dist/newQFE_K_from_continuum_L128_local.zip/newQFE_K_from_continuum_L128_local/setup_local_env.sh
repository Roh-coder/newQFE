#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKDIR="$ROOT/K_from_continuum"
VENV="$ROOT/.venv"

need_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Missing required command: $1" >&2
    exit 1
  fi
}

need_cmd python3
need_cmd make
if ! command -v g++ >/dev/null 2>&1 && ! command -v c++ >/dev/null 2>&1; then
  echo "Missing required C++ compiler: need g++ or c++" >&2
  exit 1
fi

if [[ ! -d "$VENV" ]]; then
  python3 -m venv "$VENV"
fi

# shellcheck disable=SC1091
source "$VENV/bin/activate"
export PIP_DISABLE_PIP_VERSION_CHECK=1
python -m pip install --upgrade pip
python -m pip install -r "$WORKDIR/requirements.txt"
make -C "$WORKDIR"
mkdir -p "$WORKDIR/results"

echo "Environment ready in $ROOT"
