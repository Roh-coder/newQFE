#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"$ROOT/setup_local_env.sh"
# shellcheck disable=SC1091
source "$ROOT/.venv/bin/activate"
cd "$ROOT/K_from_continuum"
python 03_score_continuum_vs_reference.py --config configs/local_L128_score.json
