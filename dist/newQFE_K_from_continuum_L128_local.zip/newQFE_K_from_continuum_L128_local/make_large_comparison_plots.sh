#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTDIR="$ROOT/K_from_continuum/results/local_iso111_ref4x_qtr_score_L128_grid7x7/comparison_analysis_data"

"$ROOT/run_score_L128.sh"

echo
if [[ -d "$OUTDIR" ]]; then
  echo "Main comparison plots:"
  echo "  $OUTDIR/score_heatmap.png"
  echo "  $OUTDIR/zscore_heatmap.png"
  echo "  $OUTDIR/score_zscore_heatmaps.png"
  echo "  $OUTDIR/fss_plots/"
else
  echo "Score output directory not found: $OUTDIR" >&2
  exit 1
fi
